SELECT
    r.nome_regiao,
    f.data_hora,
    f.consumo_mwh,
    f.duracao_interrupcao_min,
    f.status_servico
FROM fato_consumo_interrupcoes f
JOIN dim_regioes r
    ON f.id_regiao = r.id_regiao
ORDER BY f.data_hora;
